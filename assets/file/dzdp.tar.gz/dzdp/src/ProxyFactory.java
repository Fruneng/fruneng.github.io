import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URLConnection;
import java.util.ArrayList;
import java.io.*;
import java.util.regex.*;
import java.util.*;

public class ProxyFactory {

	static private int i = 0;
	static private ArrayList<Proxy> proxy_list = new ArrayList<Proxy>();
	
	static public void init()
	{
		proxy_list.clear();
		File file = new File("proxy");
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(file));
			String tempString = null;
			int line = 1;
			// 一次读入一行，直到读入null为文件结束
			while ((tempString = reader.readLine()) != null) {
				
				Pattern p = Pattern.compile("(.*?) (.*?) ");
				Matcher m = p.matcher(tempString);
				if(m.find()){
					String ip = m.group(1);
					String port = m.group(2);
					
					System.out.println("测试" + tempString);
					Proxy proxy = new Proxy(Proxy.Type.DIRECT.HTTP, new InetSocketAddress(ip, Integer.parseInt(port)));
					if(testProxy(proxy))
					{
						proxy_list.add(proxy);
						System.out.println("可用" + tempString);
					}
					else
					{
						System.out.println("不可用" + tempString);
					}
				}
		    }
		    reader.close();
		} catch (IOException e) {
		    e.printStackTrace();
		} finally {
		    if (reader != null) {
		        try {
		            reader.close();
		        } catch (IOException e1) {
		        }
		    }
		}
	}
		
	static private boolean testProxy(Proxy proxy)
	{
		boolean succ = false;
		try {
			java.net.URL url = new java.net.URL("http://www.dianping.com");
			URLConnection URLconn = url.openConnection(proxy);
			URLconn.setRequestProperty("User-Agent",
					"Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)\");");
			URLconn.setConnectTimeout(10*1000);
			URLconn.setReadTimeout(30*1000);
            BufferedReader in = new BufferedReader(new InputStreamReader(
            		URLconn.getInputStream(),"UTF-8"));
			in.close();
			succ = true;
		} catch (Exception e) { // Report any errors that arise
			System.err.println(e);
			succ = false;
		}
		return false;
	}
	
	static public Proxy getaProxy()
	{
		i++;
		i = i%proxy_list.size();
		return proxy_list.get(i);
	}
}
