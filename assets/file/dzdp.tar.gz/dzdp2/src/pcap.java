import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.io.*;
import java.util.regex.*;
import java.util.*;

import javax.swing.*;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;



public class pcap {
	private String domain = "http://www.dianping.com/shop/";
	protected String getContent(int id)
	{
		String url = domain + id;
		return getWebContent(url);
	}
	
	protected String getWebContent(String url_str)
	{
		while(true)
		{
			long now = (new Date()).getTime();
			if(now - last_req_time > req_Interval)
			{
				last_req_time = now;
				break;
			}
			try {
				java.util.concurrent.TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		StringBuffer sb = new StringBuffer();
		boolean succ = false;
		int j=0;
		do
		{
			try {
				java.net.URL url = new java.net.URL(url_str);
				//Proxy proxy = ProxyFactory.getaProxy();
				//URLConnection URLconn = url.openConnection(proxy);
				URLConnection URLconn = url.openConnection();
				URLconn.setRequestProperty("User-Agent",
						"Mozilla/5.0 (compatible; MSIE 5.0; Windows NT; DigExt)\");");
				URLconn.setConnectTimeout(10*1000);
				URLconn.setReadTimeout(30*1000);
	            BufferedReader in = new BufferedReader(new InputStreamReader(
	            		URLconn.getInputStream(),"UTF-8"));
				String line;
				while ((line = in.readLine()) != null) {
					sb.append(line);
				}
				in.close();
				succ = true;
			} catch (Exception e) { // Report any errors that arise
				sb.append(e.toString());
				System.err.println(e);
				if(j++ < 3)
				{
					create_a_browse("http://www.dianping.com");
				}
			}
		}while(!succ);
		pcap_num++;
		return sb.toString();
	}
	private int pcap_num = 0;
	private long last_req_time;
	private long req_Interval = 5 * 1000;
	protected void create_a_browse(String url)
	{
		JOptionPane.showMessageDialog( null,"抓包数 :" + pcap_num);
	}
	
	protected String getBreadcrumb(String content)
	{
		String reg = "<div class=\"breadcrumb\">(.*?)</div>";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(content);
		String ret = "";
		if(m.find()){
			String sub_content = m.group(1);
			
			String reg2 = "<span class=\"bread-name\" itemprop=\"title\">(.*?)</span>";
			Pattern p2 = Pattern.compile(reg2);
			Matcher m2 = p2.matcher(sub_content);
			while(m2.find())
			{
				ret += m2.group(1) + "|";
			}
		}else
		{
			System.out.println("can not get Breadcrumb!");
		}
		return ret;
	}

	protected String getShopname(String content)
	{
		String reg = "<h1 class=\"shop-title\" itemprop=\"name itemreviewed\">(.*?)</h1>";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(content);
		String ret = "";
		if(m.find()){
			ret = m.group(1);
		}else
		{
			System.out.println("can not get shop name!");
		}
		return ret;
	}

	protected String getTelphone(String content)
	{
		String reg = "<strong itemprop=\"tel\">(.*?)</strong>";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(content);
		String ret = "";
		if(m.find()){
			ret = m.group(1);
		}else
		{
			System.out.println("can not get Telphone!");
		}
		return ret;
	}

	protected String getPOI(String content)
	{
		String reg = "poi: '(.*?)',";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(content);
		String ret = "";
		if(m.find()){
			ret = m.group(1);
		}else
		{
			System.out.println("can not get POI");
		}
		return ret;
	}

	protected String getAddress(String content)
	{
		String reg = "<span class=\"region\" itemprop=\"locality region\">(.*?)</span></a><span itemprop=\"street-address\">(.*?)</span>";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(content);
		String ret = "";
		if(m.find()){
			ret = m.group(1) + " " + m.group(2);
		}else
		{
			System.out.println("can not get POI");
		}
		return ret;
	}
	
	public void recordInfobyid(int id)
	{
		String content = getContent(id);
		String name = getShopname(content);
		String address = getAddress(content);
		String poi = getPOI(content);
		String tel = getTelphone(content);
		String bread = getBreadcrumb(content);
		if(!record(id, name, address, poi, tel, bread))
		{
			record_err(id,"插入失败");
		}
	}

	protected boolean record_err(int id,String log)
	{
		String sql = "INSERT INTO log(pid,log) VALUES (" + id + ",'" + log + "');";
		boolean succ = true;
		try {
			Class.forName("org.sqlite.JDBC");
	
		    Connection connection = DriverManager 
		            .getConnection(db_connect_str); 
		    Statement statement = connection.createStatement(); 
		    statement.execute(sql);
		    connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			succ = false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			succ = false;
		} 
	    return succ;
	}
	
	protected boolean record(int id, String name, String address, String poi, String tel, String bread)
	{
		 
		String sql = "INSERT INTO poi VALUES (" + id + ",'" + name + "','" + address + "',0,0,'" + bread + "','" + tel + "','" + poi + "');";
		boolean succ = true;
		try {
			Class.forName("org.sqlite.JDBC");
	
		    Connection connection = DriverManager 
		            .getConnection(db_connect_str); 
		    Statement statement = connection.createStatement(); 
		    statement.execute(sql);
		    connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			succ = false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			succ = false;
		} 
	    return succ;
	}

	private String db_connect_str;
	
	public pcap(String sqlite3_conn_str)
	{
		db_connect_str = "jdbc:sqlite:" + sqlite3_conn_str;
	}
	
	public static void main(String[] args) { 
	    
		if(args.length < 2)
		{
			System.out.println("usage: java -jar xxx data_hz dzdp_hz.db3");
		}
		
		pcap p = new pcap(args[1]);
	    
	    p.do_exec(args[0]);
	}
	
	public void do_exec(String filename)
	{
        File file = new File(filename);
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            while ((tempString = reader.readLine()) != null) {
            		int id = getShopidformdataline(tempString);
            		if(id > 0)
            		{
            			recordInfobyid(id);
            			System.out.println("download data id: " + id);
            		}
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
	}
	
	public int getShopidformdataline(String content)
	{
		String reg = "<a href=\"/shop/(\\d+)\" ";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(content);
		String ret = "";
		if(m.find()){
			ret = m.group(1);
		}else
		{
			ret = "0";
		}
		return Integer.parseInt(ret);
	}

}
