
public class ParsePOI {
	static public Gps parse(String s)
	{
        int digi=16;  
        int add= 10;  
        int plus=7;  
        int cha=36;  
        int I = -1;  
        int H = 0;  
        String B = "";  
        int J = s.length();  
        char G =  s.charAt(J-1);
        s = s.substring(0, J - 1);  
        J--;  
        for (int E = 0; E < J; E++)
        {  
        	int D = Integer.parseInt(char2String(s.charAt(E)), cha) - add;  
        	if (D >= add) {  
        		D = D - plus; 
        	}  
        	B += Integer.toString(D, cha);
        	if (D > H) {  
        		I = E;  
        		H = D;
        	}  
        }  
        int A = Integer.parseInt(B.substring(0, I), digi);  
        int F = Integer.parseInt(B.substring(I + 1), digi);  
        int tg = Integer.parseInt(char2String(G),cha);
        double L = (A + F - tg) / 2.0;  
        double K = (F - L) / 100000;  
        L /= 100000;  
        
        return new Gps(L,K);
	}
	
	static private String char2String(char c)
	{
		String ret = "";
		ret += c;
		return ret;
	}
	
	public static void main(String[] args) 
	{ 
	
		Gps gps = ParsePOI.parse("IJDCWBZVFIDCFN");
		System.out.println(gps.toString());
	}
}
