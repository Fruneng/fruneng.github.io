public class Gps{
	public double _lng;
	public double _lat;
	public Gps(double lng, double lat)
	{
		_lng = lng;
		_lat = lat;
	}
	public Gps()
	{

	}
	
	public String toString()
	{
		return "lng: " + _lng + " lat :" + _lat;
	}
}