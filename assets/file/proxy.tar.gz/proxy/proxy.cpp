#include <iostream>

class OperatorBase
{
public:
    virtual int operator()(int,int) = 0;
};

class Add: public OperatorBase
{
public:
    int operator()(int a, int b)
    {
        return a+b;
    }
};

class Sub: public OperatorBase
{
public:
    int operator()(int a, int b)
    {
        return a-b;
    }
};

class Proxy
{
public:
    Proxy(OperatorBase& op):_op(op){}
    
    int operator()(int a, int b)
    {
        return _op(a,b);
    }
    
private:
    OperatorBase& _op;
};

int main()
{
    Add add;
    Sub sub;
    Proxy proxy_add(add);
    Proxy proxy_sub(sub);
    
    std::cout << "1 + 2 = " << proxy_add(1, 2) << std::endl;
    std::cout << "1 - 2 = " << proxy_sub(1, 2) << std::endl;
}
