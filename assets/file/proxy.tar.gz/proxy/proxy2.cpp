#include <iostream>
#include <functional>


int add(int a, int b)
{
    return a+b;
}

int sub(int a, int b)
{
    return a-b;
}

typedef std::function<int (int,int)> OperFunc;

int proxy(OperFunc& f, int a, int b)
{
    return f(a, b);
}

int main()
{
    OperFunc f_add = &add;
    OperFunc f_sub = &sub;
		        
    std::cout << "1 + 2 = " << proxy(f_add, 1, 2) << std::endl;
    std::cout << "1 - 2 = " << proxy(f_sub, 1, 2) << std::endl;
}
