#!/bin/bash

echo "proxy result:"
./proxy
echo "============="
echo "proxy.lua result:"
lua proxy_lua
echo "============="
echo "proxy2 result:"
./proxy2
echo "============="
