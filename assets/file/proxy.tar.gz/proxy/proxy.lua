
function add(a, b)
  return a+b;
end

function sub(a, b)
  return a-b;
end

function proxy(op, a, b)
  return op(a, b)
end

print("1 + 2 = ".. tostring(proxy(add, 1, 2)));
print("1 - 2 = ".. tostring(proxy(sub, 1, 2)));

--[==[
print(
  proxy(
    function (a,b) 
      return a*b; 
    end, 1, 2));
]==]--
